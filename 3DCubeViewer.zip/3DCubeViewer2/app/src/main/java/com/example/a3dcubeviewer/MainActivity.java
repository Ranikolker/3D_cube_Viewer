package com.example.a3dcubeviewer;

import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.ar.sceneform.HitTestResult;
import com.google.ar.sceneform.Node;
import com.google.ar.sceneform.Scene;
import com.google.ar.sceneform.math.Quaternion;
import com.google.ar.sceneform.math.Vector3;
import com.google.ar.sceneform.rendering.ModelRenderable;
import com.google.ar.sceneform.ux.FootprintSelectionVisualizer;
import com.google.ar.sceneform.ux.TransformableNode;
import com.google.ar.sceneform.ux.TransformationSystem;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    private Scene scene;
    private TransformableNode modelNode;
    private TransformationSystem transformationSystem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup the SceneForm view
        com.google.ar.sceneform.SceneView sceneView = findViewById(R.id.sceneView);
        scene = sceneView.getScene();

        // Setup transformation system for interaction with the model
        transformationSystem = new TransformationSystem(
                getResources().getDisplayMetrics(),
                new FootprintSelectionVisualizer());

        // Setup buttons
        Button btnRotateLeft = findViewById(R.id.btnRotateLeft);
        Button btnRotateRight = findViewById(R.id.btnRotateRight);

        btnRotateLeft.setOnClickListener(v -> rotateModel(-90f));
        btnRotateRight.setOnClickListener(v -> rotateModel(90f));

        // Add light
        Node lightNode = new Node();
        lightNode.setLocalPosition(new Vector3(0, 10f, 0));
        scene.addChild(lightNode);

        // Load the 3D model
        loadModel();

        // Enable the scene
        sceneView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                HitTestResult hitResult = sceneView.getScene().hitTest(event);
                return true;
            }
            return false;
        });
    }

    private void loadModel() {
        // Use Uri to load asset
        Uri modelUri = Uri.fromFile(new File(this.getFilesDir(), "cube.glb"));

        ModelRenderable.builder()
                .setSource(this, modelUri)
                .build()
                .thenAccept(model -> {
                    // Create a node for the model
                    modelNode = new TransformableNode(transformationSystem);
                    modelNode.setRenderable(model);

                    // Position the model
                    modelNode.setLocalPosition(new Vector3(0f, 0f, -1.5f));

                    // Add model to the scene
                    scene.addChild(modelNode);
                    modelNode.select();

                    Toast.makeText(this, "Model loaded successfully", Toast.LENGTH_SHORT).show();
                })
                .exceptionally(throwable -> {
                    String errorMsg = "Error loading model";
                    if (throwable != null) {
                        errorMsg = "Error loading model: " + throwable.getMessage();
                    }
                    Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show();
                    return null;
                });
    }

    private void rotateModel(float angleDegrees) {
        if (modelNode != null) {
            // Convert degrees to radians
            float angleRadians = (float) Math.toRadians(angleDegrees);

            // Current rotation
            Quaternion currentRotation = modelNode.getLocalRotation();

            // Create rotation quaternion around y-axis
            Quaternion yRotation = Quaternion.axisAngle(new Vector3(0, 1, 0), angleDegrees);

            // Apply the rotation
            modelNode.setLocalRotation(Quaternion.multiply(currentRotation, yRotation));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Special handling if needed
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Special handling if needed
    }
}